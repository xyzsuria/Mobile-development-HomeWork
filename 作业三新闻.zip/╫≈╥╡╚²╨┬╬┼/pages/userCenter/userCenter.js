// pages/userCenter/userCenter.js
Page({
  data: {

    section1: {
      imagesrc: "../../imges/UserCenter/arrowRight.png",
      imagename: "我的动态"
    },
    section2: [{
      imagesrc: "../../imges/UserCenter/arrowRight.png",
      imagename: "摇一摇"
    }, {
      imagesrc: "../../imges/UserCenter/arrowRight.png",
      imagename: "附近的人"
    },
    ],
    section3: [{
      imagesrc: "../../imges/UserCenter/arrowRight.png",
      imagename: "我的消息"
    }, {
      imagesrc: "../../imges/UserCenter/arrowRight.png",
      imagename: "我的钱包"
    }, {
      imagesrc: "../../imges/UserCenter/arrowRight.png",
      imagename: "我的任务"
    }, {
      imagesrc: "../../imges/UserCenter/arrowRight.png",
      imagename: "意见反馈"
    }, {
      imagesrc: "../../imges/UserCenter/arrowRight.png",
      imagename: "关于我们"
    }]
  },
  onLoad: function (options) {
    // 页面初始化 options为页面跳转所带来的参数
  },
  onReady: function () {
    // 页面渲染完成
  },
  onShow: function () {
    // 页面显示
  },
  onHide: function () {
    // 页面隐藏
  },
  onUnload: function () {
    // 页面关闭
  }
})