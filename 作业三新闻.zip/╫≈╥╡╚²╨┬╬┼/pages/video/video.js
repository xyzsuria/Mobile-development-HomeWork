Page({
  data: {
    list: [
     
      {
        goto: '../film/film',
        pic: '../../imges/2.jpg',
        playcout: '100',
        comment: '真搞笑'
      },
      {
        goto: '../film/film',
        pic: '../../imges/3.jpg',
        playcout: '400',
        comment: '一般'
      },
      {
        goto: '../film/film',
        pic: '../../imges/4.jpg',
        playcout: '10',
        comment: '真好看'
      },
      {
        goto: '../film/film',
        pic: '../../imges/5.jpg',
        playcout: '100',
        comment: '真搞笑'
      },
      {
        goto: '../film/film',
        pic: '../../imges/6.jpg',
        playcout: '400',
        comment: '一般'
      },
      {
        goto: '../film/film',
        pic: '../../imges/1.jpg',
        playcout: '10',
        comment: '真好看'
      },
    ]
  },

  onLoad: function () {

  }
})

