// pages/attention/attention.js
Page({
  data: {
    item: [{
      index: 1,
      msg: '您关注了一条视频新闻',
      time: '2017-05-01'
    },{
      index: 2,
      msg: '您关注了一条财经新闻',
      time: '2017-05-02'
    },{
      index: 3,
      msg: '您关注了一条科技新闻',
      time: '2017-05-03'
    },{
      index: 4,
      msg: '您关注了一条体育新闻',
      time: '2017-05-04'
    }]
  }
})