//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    // num: 1,
    // message: [
    //   {
    //     id: '1',
    //     text: "今日头条"
    //   },
    //   {
    //     id: '2',
    //     text: '趣头条'
    //   },
    //   {
    //     id: '3',
    //     text: '百家号'
    //   },
    //   {
    //     id: '4',
    //     text: '企鹅号'
    //   }, {
    //     id: '5',
    //     text: '大鱼号'
    //   }
    // ]
  },
  // clickList: function (e) {
  //   console.log(e)
  //   let num = e.target.dataset.num
  //   this.setData({
  //     num: num
  //   })
  //   console.log(this)
  // },
  onLoad: function () {
  
  }
})
