// pages/movepage/movepage.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    //初始化数据
    hideNotice: false,
    notice: '滚动的文字',
    imgUrls: [
      "../image/p6.jpg",
      "../image/p7.jpg",
      "../image/p8.jpg",
      "../image/p9.jpg",
      "../image/p10.jpg",
      "../image/p11.jpg"
    ]
  },
// 点击关闭公告
  switchNotice: function () {
    this.setData({
      hideNotice: true
    })
    },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },
  toupper: function () {
    console.log("触发了toupper");
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */

  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})