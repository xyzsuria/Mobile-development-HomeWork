// pages/copybook/copybook.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    array:"",
    // array:[
    //   {
    //     content:"内心不渴望的东西，不可能靠近自己。",
    //     book:"无名",
    //     time:"2020/4/27",
    //     feeling:"",
    //   },
    //   {
    //     content: "等你发现时间是贼了，它早已偷光了你的选择。",
    //     book: "滴答清单",
    //     time: "2020/4/26",
    //     feeling: "",
    //   },
    //   {
    //     content: "不要因为当初走的太远忘记为何出发。",
    //     book: "滴答",
    //     time: "2020/4/26",
    //     feeling: "",
    //   },
    // ],
    bookcontents:[],
    bookcontent:"",
    focus: false,
    // inputValue: ''
    disabled: false,
    plain: false,
    loading: false,
    x:[],
  },
  bindTextAreaBlur: function (e) {
    console.log(e.detail.value)
    
  },
  formSubmit: function (e) {
    console.log('form发生了submit事件，数据为：', e.detail.value)
    var bookdata = {
      content: e.detail.value['textarea'], 
      book: e.detail.value['input'],
      feeling: e.detail.value['inputyour'],
      time: e.detail.value['wtime']
    };
    this.data.array.push(bookdata)
    console.log(this.data.array)
    this.setData(
      {
        array:this.data.array
      }
    )
    wx.request({
      url: 'http://127.0.0.1:5000/add',
      method: 'POST',
      header:{
        'content-type':'application/json'
      },
      data:{
        'form':bookdata,
      },
    })
    // console.log(bookdata)
    // 这个用不到
    // let socketOpen = true
    // // const socketMsgQueue = []
    // wx.connectSocket({
    //   url: ' https://xyzsuria.github.io/',
    //   success: res => {
    //     console.log("成功lllll")},
    //   fail: res => {
    //     console.log("失败lllll")
    //   }
    // })
    // function sendSocketMessage(msg) {
    //   if (socketOpen) {
    //     wx.sendSocketMessage({
    //       data: bookdata,
    //     })
    //     console.log("成功了！")
    //   } else {
    //     socketMsgQueue.push(bookdata)
    //   }
    // }

    // wx.onSocketOpen(function(res){
    //   socketOpen = true
    //   for (let i=0; i < socketMsgQueue.length; i++){
    //     sendSocketMessage(socketMsgQueue[i])
    //   }
    //   let socketMsgQueue = []
    // })

    
    // this.setData({
    //   array: this.data.array
    // })
    // var bookname = e.detail.value['input'];
    
    // console.log("data",data)
    // wx.setStorage({
    //   key: 'bookcontents',
    //   data: bookdata,
    // });
    // wx.switchTab({
    //   url: 'copybook',
    // })
    // this.setData({
    //   array: (wx.getStorageSync('x') || []).map(item => {
    //     item = e.detail.value['textarea']
    //     return item
    //   })
    // })
  },
  formReset: function () {
    console.log('form发生了reset事件')
  },
  /**
   * 生命周期函数--监听页面加载
   */
  // submit:  function(e){
  //   console.log(e.detail.value)
  // },
  onLoad: function (options) {
    // var book = wx.getStorageSync('bookcontents');//wx.getStorageSync(key)，获取本地缓存
    // this.setData({
    //   bookcontents: book
    // });
    wx.request({
      url: 'http://127.0.0.1:5000/word',
      // ans:{},
      // method:'POST',
      success: res => {
        console.log(res.data['data'])
        this.setData(
          {
            array: res.data['data']
          }
        )},
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

})