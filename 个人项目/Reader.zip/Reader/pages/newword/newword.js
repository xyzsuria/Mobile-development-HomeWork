// pages/newword/newword.js
var y="xxxxx"
Page({

  /**
   * 页面的初始数据
   */
  data: {
    x:y,
    all:'',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
  Try:function(){
    wx.request({
    url: 'http://127.0.0.1:5000/',
    // ans:{},
    // method:'POST',
      success: res => {
        console.log(res.data['data'][0])
        console.log("成功")
        this.setData(
          {
            ans: res.data['data'][0]
          }
        )

      },
    // success:function(res){
    //   console.log(res.data),
    //   this.setData(
    //     {
    //     ans:res.data,
    //     }
    //   )
    // },
    
  })
  this.setData(
    {
      all:
      [{
        'x':'马上要交作业了',
        y:'我要抓紧时间写了',
        z:'韩剧真好看',
      },
      {
        'x': '徐文静',
        y: '你清醒一点',
        z: '别看韩剧了',
      }
      ]
    }
  )
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },
  
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})