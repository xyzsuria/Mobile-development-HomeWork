// pages/read/read.js
var id
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData(
      {
        id:options["bookid"],
        url: 'src/cma/' + options["bookid"]+'.txt',
        // url: 'src/cma/《我希望有人在什么地方等我》.pdf',
      }
    )
    console.log(this.data.url)
    // 由于打不开
    // console.log("123456")
    // var url = 'http://yzb.buaa.edu.cn/system/_content/download.jsp?urltype=news.DownloadAttachUrl&owner=1403782683&wbfileid=4447636';
    // //下载文件，生成临时地址
    // wx.downloadFile({
    //   url: url,
    //   success(res) {
    //     // console.log(res)
    //     //保存到本地
    //     wx.saveFile({
    //       tempFilePath: res.tempFilePath,
    //       success: function (res) {
    //         const savedFilePath = res.savedFilePath;
    //         // 打开文件
    //         wx.openDocument({
    //           filePath: savedFilePath,
    //           success: function (res) {
    //             console.log('打开文档成功')
    //           },
    //         });
    //       },
    //       fail: function (err) {
    //         console.log('保存失败：', err)
    //       }
    //     });
    //   }
    // })
    // 直接尝试打开pdf文件
    // wx.openDocument({
    //   filePath: 'src/cma/《我希望有人在什么地方等我》.pdf',
    //   fileType: 'pdf',
    //   success: function (res) {
    //     console.log('打开文档成功')
    //   },
    // });

    wx.getFileSystemManager().readFile({
      // filePath: BookList[0],
      filePath: this.data.url,
      encoding: 'utf-8',
      success: res => {
        console.log(res.data)
        // console.log(this.data.url)
        console.log("成功")
        this.setData(
          {
            all: res.data
          }
        )

      },
      fail: console.error		//复制失败返回error
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

   

})