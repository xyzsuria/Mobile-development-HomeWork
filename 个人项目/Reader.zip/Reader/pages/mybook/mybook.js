// pages/mybook/mybook.js
Page({

  data: {
    array:[
      {
        bookid:"0",
        name:"Born a crime",
        author:"Trevor Noah",
        content: "讲述了主人公作为混血儿在种族制度严格的环境下成长的故事。",
        src:"../../images/bron a crime.jpg",
      },
      {
        bookid:"2",
        name:"Atomic hobby",
        src: "../../images/b.jpg",

      },
      {
        bookid: "1",
        name: "破云2 吞海",
        author:"淮上",
        content: "讲述了一对警察在破案过程中，互相帮助，共同成长的故事。",
        src: "../../images/poyun.jpg",
      },

    ],
    content:"123456789",
    all:"",
  },
  ToRead: function(e){
    console.log(e)
    wx.navigateTo({
      url: '../read/read?bookid=' + e.currentTarget.id,
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  book1: function (){
    wx.getFileSystemManager().readFile({
      // filePath: BookList[0],
      filePath : 'src/cma/try.txt',
      encoding : 'utf-8',
      success: res => {
        console.log(res.data)
        console.log("成功")
        // this.setData(
        //   {
        //     all : res.data
        //   }
        // )
        
      },
      fail: console.error		//复制失败返回error
    })
    wx.navigateTo({
      url: 'read.wxml',
    })
  },

  book2: function () {
    wx.getFileSystemManager().readFile({
      // filePath: BookList[0],
      filePath: 'src/cma/try.txt',
      encoding: 'utf-8',
      success: res => {
        console.log(res.data)
        console.log("成功")		//
      },
      fail: console.error		//复制失败返回error
    })
  },

})