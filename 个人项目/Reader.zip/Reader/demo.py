from flask import Flask, request, make_response
import json
from flask_cors import *
app = Flask(__name__)
CORS(app, support_credentials=True)


def addone(x):
  f1 = open('new.json','r',encoding='utf-8')
  f2 = json.load(f1)
  print(f2['data'])
  print(type(f2))
  f2['data'].append(x)
  # print(f2)
  with open("new.json", 'w', encoding='utf-8') as f3:
      f3.write(json.dumps(f2, indent=4))


def OpenJson(name):
    with open('json/{}.json'.format(name),'r',encoding='utf-8') as f:
        c = f.read()
        return json.loads(c)


@app.route('/')
def try_setMessage():
    s = OpenJson('test')
    return s
    # return 'Onemoretime'

@app.route('/word')
def OpenWordLists():
    word = OpenJson('new')
    return word

@app.route('/add', methods=['GET','POST'])
def addlist():
    message = request.data
    more = 'lllll'
    print(message)
    m = str(message)
    # mjson = json.load(m)
    mjson = eval(m)
    print(type(mjson))
    print(mjson)
    print(more)
    return message


if __name__ == "__main__":
    app.run()
