import json

data1 = """那些窥探的触角隐藏在互联网浪潮中，无处不在，生生不息，正逐渐将现代社会的每个角落淹没至顶。
“深渊中隐藏着庞大、复杂、根深蒂固的犯罪网，‘马里亚纳海沟’远比警方所知的更加深邃，却又近在你我身后——”
津海市公安局新来的吴雩温和懦弱、寡言少语，对来自严厉上司的刁难毫不在意，只想做个按时领工资混饭吃的背景板。
　　没人知道这个年轻人有一颗被毒枭重金悬赏的项上头颅，和曾经深渊屠龙的少年肝胆。
　　现代都市刑侦，作风冷淡严厉强势注重健康热爱养生学院派精英攻&得过且过不想干活平生最烦学院派最讨厌被领导的受
"""
# 打开文件，读取txt文件内容
file = open("../src/cma/1.txt","r",encoding='utf-8')
data = file.read()
file.close()

# print(data)
SentenceData = {}
# 按照换行符分隔
number = 0
for sentence in data.split('\n'):
    # 将数据整合成字典形式
    SentenceData[number] = sentence
    number+=1
# 创建test.json文件，并将数据写入其中
with open("test.json","w",encoding="utf-8") as f:
    f.write(json.dumps(SentenceData,indent=4))
