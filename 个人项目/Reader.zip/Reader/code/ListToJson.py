import json

array={"data":[
      {
        'content':"内心不渴望的东西，不可能靠近自己。",
        'book':"无名",
        'time':"2020/4/27",
        'feeling':"说得对",
      },
      {
        'content': "等你发现时间是贼了，它早已偷光了你的选择。",
        'book': "滴答清单",
        'time': "2020/4/26",
        'feeling': "真可悲",
      },
      {
        'content': "不要因为当初走的太远忘记为何出发。",
        'book': "滴答",
        'time': "2020/4/26",
        'feeling': "好的",
      },]}

# with open("new1.json",'w',encoding='utf-8') as f:
#     f.write(json.dumps(array,indent=4))
x1 = '''{"form":{
      'content': "一aaaaaaaqqqqq",
      'book': "倒计时",
      'time': "2020/4/30",
      'feeling': "说的不错",}}'''


def addone(x):
  f1 = open('new1.json','r',encoding='utf-8')
  f2 = json.load(f1)
  print(f2['data'])
  print(type(f2))
  f2['data'].append(x)
  # print(f2)
  with open("new1.json", 'w', encoding='utf-8') as f3:
      f3.write(json.dumps(f2, indent=4))

x2 = x1[8:-1]
print(type(x2))
addone(x2)


