import re
import json

def ForJson():
    # 文件路径
    path = "../../txt"
    # 读取文件
    with open(path,"r",encoding="utf-8") as file:
        